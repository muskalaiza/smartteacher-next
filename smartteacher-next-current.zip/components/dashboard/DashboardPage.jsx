"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import {
  addOrReactivateTeacherSubject,
  deactivateTeacherSubject,
  getCurrentDashboardUser,
  listActiveTeacherSubjects,
  listAllActiveSubjects,
} from "@/lib/teacherSubjects/teacherSubjectsApi";

export default function DashboardPage() {
  const router = useRouter();

  const [user, setUser] = useState(null);
  const [teacherSubjects, setTeacherSubjects] = useState([]);
  const [allSubjects, setAllSubjects] = useState([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [message, setMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
  async function loadDashboard() {
    setIsLoading(true);
    setErrorMessage("");
    setMessage("");

    try {
      const currentUser = await getCurrentDashboardUser(supabase);

      setUser(currentUser);

      const [teacherSubjectsData, allSubjectsData] = await Promise.all([
        listActiveTeacherSubjects({
          supabase,
          userId: currentUser.id,
        }),
        listAllActiveSubjects(supabase),
      ]);

      setTeacherSubjects(teacherSubjectsData);
      setAllSubjects(allSubjectsData);
    } catch (error) {
      if (error.message === "AUTH_REQUIRED") {
        router.push("/");
        return;
      }

      setErrorMessage(error.message);
    } finally {
      setIsLoading(false);
    }
  }

  loadDashboard();
}, [router]);

  const availableSubjects = useMemo(() => {
    const addedSubjectIds = new Set(
      teacherSubjects.map((item) => item.subject_id)
    );

    return allSubjects.filter((subject) => !addedSubjectIds.has(subject.id));
  }, [allSubjects, teacherSubjects]);

  const teacherFirstName = useMemo(() => {
  const fullName = user?.user_metadata?.full_name?.trim()

  if (!fullName) {
    return ""
  }

  return fullName.split(/\s+/)[0]
}, [user])

async function refreshTeacherSubjects(userId) {
  const teacherSubjectsData = await listActiveTeacherSubjects({
    supabase,
    userId,
  });

  setTeacherSubjects(teacherSubjectsData);
}

  async function handleAddSubject(event) {
  event.preventDefault();

  setIsAdding(true);
  setErrorMessage("");
  setMessage("");

  try {
    await addOrReactivateTeacherSubject({
      supabase,
      userId: user?.id,
      subjectId: selectedSubjectId,
    });

    setSelectedSubjectId("");
    setMessage("Przedmiot został dodany do Twojego panelu.");
    await refreshTeacherSubjects(user.id);
  } catch (error) {
    setErrorMessage(error.message);
  } finally {
    setIsAdding(false);
  }
}

async function handleDeactivateSubject(teacherSubjectId) {
  setErrorMessage("");
  setMessage("");

  try {
    await deactivateTeacherSubject({
      supabase,
      userId: user?.id,
      teacherSubjectId,
    });

    setMessage("Przedmiot został usunięty z Twojego panelu.");
    await refreshTeacherSubjects(user.id);
  } catch (error) {
    setErrorMessage(error.message);
  }
}


 function handleOpenSubject(subjectKey) {
  router.push(`/przedmioty/${encodeURIComponent(subjectKey)}/generator`);
}


  if (isLoading) {
    return (
      <div className="space-y-4">
        <h1 className="text-3xl font-bold text-zinc-100">
          Ładowanie panelu...
        </h1>
        <p className="text-zinc-400">
          Sprawdzamy Twoje konto i przedmioty.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
       <h1 className="text-3xl font-bold text-zinc-100">
          Dzień dobry{teacherFirstName ? `, ${teacherFirstName}` : ""} 👋
      </h1>


        <p className="mt-2 text-zinc-400">
          Wybierz przedmiot, którego uczysz, albo dodaj nowy z katalogu.
        </p>
      </div>

      {errorMessage && (
        <div className="rounded-lg border border-red-900/50 bg-red-950/30 p-3 text-sm text-red-300">
          {errorMessage}
        </div>
      )}

      {message && (
        <div className="rounded-lg border border-emerald-900/50 bg-emerald-950/30 p-3 text-sm text-emerald-300">
          {message}
        </div>
      )}

      <section>
        <h2 className="mb-4 text-xl font-semibold text-zinc-100">
          Moje przedmioty
        </h2>

        {teacherSubjects.length === 0 ? (
          <div className="rounded-xl border border-dashed border-zinc-700 bg-zinc-900/40 p-6 text-zinc-400">
            Nie masz jeszcze dodanych przedmiotów. Dodaj pierwszy przedmiot z
            katalogu poniżej.
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-3">
            {teacherSubjects.map((item) => {
              const subject = item.subjects;

              if (!subject) return null;

              return (
               
               <div
  key={item.id}
  className="rounded-xl border border-zinc-800 bg-zinc-900 p-6 text-zinc-300 transition-all duration-150 hover:border-zinc-700 hover:bg-zinc-800"
>
  <span className="block text-base font-semibold text-zinc-100">
    {subject.name}
  </span>

  <span className="mt-2 block text-xs text-zinc-500">
    {subject.subject_key}
  </span>

  <div className="mt-5 flex flex-wrap gap-2">
    <button
      type="button"
      onClick={() => handleOpenSubject(subject.subject_key)}
      className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-medium text-white transition-colors hover:bg-indigo-500"
    >
      Otwórz
    </button>

    <button
      type="button"
      onClick={() => handleDeactivateSubject(item.id)}
      className="rounded-md border border-red-900/60 px-3 py-2 text-sm font-medium text-red-300 transition-colors hover:bg-red-950/40 hover:text-red-200"
    >
      Usuń z panelu
    </button>
  </div>
</div>
              );
            })}
          </div>
        )}
      </section>

      <section className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
        <h2 className="text-lg font-semibold text-zinc-100">
          Dodaj przedmiot
        </h2>

        <p className="mt-1 text-sm text-zinc-400">
          Wybierz przedmiot ze wspólnego katalogu SmartTeacher.
        </p>

        <form onSubmit={handleAddSubject} className="mt-4 flex flex-col gap-3 md:flex-row">
          <select
            value={selectedSubjectId}
            onChange={(event) => setSelectedSubjectId(event.target.value)}
            disabled={availableSubjects.length === 0 || isAdding}
            className="min-h-10 flex-1 rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-zinc-200 outline-none transition-colors focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <option value="">
              {availableSubjects.length === 0
                ? "Wszystkie dostępne przedmioty są już dodane"
                : "Wybierz przedmiot"}
            </option>

            {availableSubjects.map((subject) => (
              <option key={subject.id} value={subject.id}>
                {subject.name}
              </option>
            ))}
          </select>

          <button
            type="submit"
            disabled={!selectedSubjectId || isAdding}
            className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {isAdding ? "Dodawanie..." : "+ Dodaj przedmiot"}
          </button>
        </form>
      </section>
    </div>
  );
}

