# SmartTeacher — database_architecture_v1.md

**Wersja dokumentu:** 2.7  
**Data aktualizacji:** 04.08.2026  
**Projekt:** `smartteacher-next`  
**Supabase:** `smartteacher-next-dev`  
**Status:** aktualna architektura robocza; Generator kartkówki i karty pracy, atomowy cache, Historia, wspólny klucz, punktacja, indywidualna skala ocen i eksport DOCX są wdrożone  
**Uwaga:** nazwa pliku pozostaje bez zmiany ze względu na ciągłość źródeł projektu.

---

## 0. CEL DOKUMENTU

Dokument opisuje aktualny model danych SmartTeacher oraz decyzje obowiązujące przy dalszym rozwoju Generatora kartkówki i karty pracy, cache, Historii, wspólnego klucza nauczyciela, punktacji, indywidualnej skali ocen i eksportu DOCX.

Nie jest jedną migracją SQL. Rzeczywiste migracje znajdują się w:

```text
supabase/sql
```

Źródłem prawdy dla bieżącego stanu jest:

- aktualny schemat Supabase,
- migracje zapisane w repo,
- działający kod `smartteacher-next`,
- zakończone testy opisane w `smartteacher_etapy.md`.

Historyczna migracja albo nazwa używana w starym module nie zastępuje kontroli rzeczywistego schematu.

---

## 1. ZASADY ARCHITEKTONICZNE

### 1.1. Prywatność

Każda prywatna tabela nauczyciela musi mieć:

```text
owner_id = auth.uid()
```

oraz RLS.

Frontend może odczytywać własne dane zgodnie z polityką. Operacje wymagające klucza `service_role` odbywają się wyłącznie po stronie serwera.

### 1.2. Najmniejsze konieczne uprawnienia

- `anon` i `authenticated` nie otrzymują uprawnień do serwerowych funkcji cache,
- `authenticated` ma wyłącznie `SELECT` do `generated_materials`,
- `anon` nie ma grantu do `generated_materials`,
- `claim_generated_material` może wykonywać `service_role`,
- `service_role` ma `SELECT` na `public.subjects`, ponieważ Route Handler zapisuje snapshot nazwy przedmiotu,
- `create_private_lesson_catalog_from_import(uuid, uuid, uuid, text, text, text)` może wykonywać `authenticated`,
- aktualna funkcja importu CSV nie jest wykonywalna przez `PUBLIC` ani `anon`,
- `authenticated` ma `SELECT`, `INSERT` i `UPDATE` wyłącznie do własnego rekordu w `teacher_grade_scales`,
- `anon` nie ma grantu do `teacher_grade_scales`,
- nie nadajemy dodatkowych praw zapisu, jeśli nie są potrzebne.

### 1.3. Jedna odpowiedzialność

Nie tworzymy tabel „na zapas”. Nowa tabela jest uzasadniona tylko wtedy, gdy przechowuje odrębny byt biznesowy albo usuwa realną redundancję.

### 1.4. Struktura przed promptem

```text
relacje
→ constraints
→ JSON Schema
→ parser
→ renderery
→ prompt
```

Model nie może zastępować walidacji, relacji ani reguł strukturalnych.

### 1.5. CSV i DOCX mają różne role

```text
CSV
→ katalog działów i tematów

DOCX
→ treść merytoryczna jednego tematu
```

CSV jest źródłem importu. Źródłem prawdy dla Generatora jest katalog relacyjny i przypisany dokument.

---

## 2. GŁÓWNA OŚ DANYCH

```text
auth.users
→ teacher_profiles
→ teacher_subjects
→ subjects

lesson_plan_imports
→ lesson_plan_items
→ lesson_catalogs
→ lesson_sections
→ lesson_topics

lesson_topics
→ teacher_documents
→ document_blocks
→ document_chunks
→ source_fingerprint

lesson_topics + teacher_documents + parametry Generatora
→ generation_fingerprint
→ claim_generated_material
→ generated_materials

generated_materials
→ lista Historii
→ pojedynczy content_json
→ GeneratedMaterial
→ materiały uczniów
→ jeden wspólny TeacherAnswerKey
→ wydruk / PDF
→ eksport DOCX na żądanie

auth.users
→ teacher_grade_scales
→ aktualna skala konta
→ TeacherAnswerKey i eksport DOCX
```

---

## 3. KATALOG LEKCJI

### `subjects`

Globalny słownik przedmiotów.

Rzeczywista kolumna nazwy przedmiotu:

```text
name
```

Nie używać nieistniejącego pola `display_name`.

Najważniejsze pola:

```text
id
subject_key
name
is_active
```

### `grade_levels`

Globalny słownik poziomów klas. Nie zapisujemy klas organizacyjnych typu `1a`, `1b`, `1c`.

### `teacher_subjects`

Relacja nauczyciela z aktywnymi przedmiotami.

### `lesson_plan_imports`

Metadane importu CSV.

### `lesson_plan_items`

Wiersze źródłowego CSV.

### `lesson_catalogs`

Prywatny katalog nauczyciela dla przedmiotu i klasy.

### `lesson_sections`

Działy w katalogu.

### `lesson_topics`

Tematy lekcji.

Klucz operacyjny Generatora:

```text
lesson_topic_id
```

Tytuł tematu jest przechowywany w:

```text
display_title
```

### 3.1. RPC tworzenia katalogu z importu CSV

Aktualna i jedyna obowiązująca sygnatura:

```text
create_private_lesson_catalog_from_import(
  p_import_id uuid,
  p_owner_id uuid,
  p_grade_level_id uuid,
  p_title text,
  p_curriculum_level text,
  p_language text
)
```

Funkcja:

- działa jako `SECURITY DEFINER`,
- wymaga jawnego `grade_level_id`,
- jest wykonywalna przez `authenticated`,
- nie jest wykonywalna przez `PUBLIC` ani `anon`.

Stare przeciążenie bez `p_grade_level_id` zostało usunięte. Nie należy go odtwarzać ani wywoływać.

---

## 4. DOKUMENTY NAUCZYCIELA

### 4.1. `teacher_documents`

Odpowiedzialność:

- metadane uploadu,
- właściciel i przedmiot,
- przypisanie do `lesson_topic_id`,
- status przetwarzania,
- ścieżka w prywatnym Storage,
- tożsamość pełnej treści źródłowej.

DOCX jest rozpoznawany przez:

```text
mime_type = application/vnd.openxmlformats-officedocument.wordprocessingml.document
```

Nie istnieje pole `doc_type`.

Wdrożone pola tożsamości:

| Kolumna | Odpowiedzialność |
|---|---|
| `source_fingerprint` | SHA-256 kanonicznego manifestu pełnej treści po chunkingu |
| `source_manifest_version` | wersja kontraktu fingerprintu, obecnie `document_chunks_v1` |
| `ready_at` | moment uzyskania kompletnej tożsamości źródła i przypisania do tematu |

`source_fingerprint` i `source_manifest_version` muszą być jednocześnie ustawione albo jednocześnie `NULL`.

### 4.2. `document_blocks`

Source-only wynik extraction.

Blok zachowuje między innymi:

```text
block_index
block_type
heading_path
content
content_hash
is_excluded
exclude_reason
```

Extraction:

- nie używa modelu,
- nie parafrazuje,
- nie dopisuje treści,
- zachowuje kolejność dokumentu.

### 4.3. `document_chunks`

Deterministyczne grupowanie bloków.

Chunk zachowuje między innymi:

```text
chunk_index
content
content_hash
heading_path
block_indices
chunking_version
```

Chunki są źródłem pełnego kontekstu Generatora.

### 4.4. `document_embeddings`

Embeddingi istnieją i pozostają w bazie.

Nie są warunkiem aktualnego generowania dla jednego krótkiego DOCX przypisanego do tematu.

Mogą zostać wykorzystane później dla:

- wielu dokumentów,
- długich źródeł,
- globalnej bazy SmartTeacher,
- retrieval potwierdzonego pomiarem jakości.

---

## 5. SOURCE FINGERPRINT

### 5.1. Cel

Fingerprint odpowiada na pytanie:

> Czy treść przekazywana Generatorowi jest dokładnie tą samą treścią i strukturą co wcześniej?

Nie jest hashem binarnego pliku DOCX.

### 5.2. Manifest

Obecny kontrakt:

```text
sourceManifestVersion = document_chunks_v1
chunkingVersion
chunks [
  chunkIndex
  contentHash
  headingPath
]
```

Kanoniczny JSON manifestu:

```text
SHA-256
→ source_fingerprint
```

### 5.3. Kontrola przed generowaniem

`getLessonTopicSourceContext.js`:

- wymaga dokładnie jednego DOCX,
- wymaga gotowego statusu, fingerprintu, manifest version i `ready_at`,
- pobiera wszystkie chunki w kolejności,
- kontroluje wspólną wersję chunkingu,
- odtwarza tożsamość źródła,
- porównuje ją z rekordem dokumentu,
- buduje pełny `sourceContext`.

Brak dokumentu jest kontrolowanym przypadkiem biznesowym `no_sources`. Niespójność fingerprintu jest błędem integralności i zatrzymuje Generator.

---

## 6. GENERATOR — WDROŻONY PRZEPŁYW

Dla jednego krótkiego dokumentu przypisanego do tematu:

```text
lesson_topic_id
→ teacher_documents
→ wszystkie document_chunks w kolejności
→ pełny source-only context
→ templates.js
→ buildTaskPlan dla 5 / 6 / 7 zadań
→ generation_fingerprint
→ atomowy claim cache
→ generated_materials
```

W głównym runtime nie używamy:

- semantic retrieval,
- top 3,
- progu similarity,
- task type coverage,
- `isSupported`,
- cache coverage.

Route Handler obecnie obsługuje pionowe przepływy:

```text
kartkówka
karta pracy
```

`sprawdzian` pozostaje nieaktywny do osobnego audytu zakresu źródeł.

Dla karty pracy wynik zawiera:

```text
intro
tip[]
glossary[]
tasks[]
```

`glossary` jest renderowany wyłącznie dla profilu Obcojęzycznego. Wszystkie profile korzystają z tego samego bazowego zestawu `tasks`.

---

## 7. `generated_materials`

Tabela jest wdrożona i używana przez runtime. Pełni dwie funkcje:

```text
cache gotowych wyników
+
źródło Historii Generowań
```

### 7.1. Relacje i snapshoty

Najważniejsze pola:

```text
owner_id
subject_id
lesson_topic_id
source_document_id
subject_name_snapshot
topic_title_snapshot
source_file_name_snapshot
```

Snapshoty utrzymują czytelność Historii nawet po późniejszej zmianie lub usunięciu rekordu źródłowego.

### 7.2. Parametry materiału

```text
material_type
task_count
profiles
task_plan
```

Dopuszczalne:

```text
material_type:
- karta pracy
- kartkówka
- sprawdzian

task_count:
- 5
- 6
- 7
```

Długość `task_plan` musi odpowiadać `task_count`.

Profile:

```text
Standard
Dysleksja
ASD
ADHD
Obcojęzyczny
```

### 7.3. Tożsamość i wersje

```text
source_fingerprint
source_manifest_version
generation_fingerprint
generator_version
content_schema_version
model
```

Aktualne wersje kontraktów:

```text
karta pracy → material_schema_v3
kartkówka    → material_schema_v2
sprawdzian  → material_schema_v2
```

Wersja jest częścią `generation_fingerprint`, dlatego zmiana kontraktu powoduje cache MISS bez zmiany schematu tabeli.

Klucz cache:

```text
unique(owner_id, generation_fingerprint)
```

### 7.4. Wynik i status

```text
status:
- generating
- ready
- failed
```

`content_json`:

- przechowuje wynik po Structured Outputs i parserze,
- nie przechowuje surowej odpowiedzi modelu,
- nie przechowuje HTML.

Spójność:

```text
generating → brak content_json i completed_at
ready      → content_json istnieje, brak error_message
failed     → brak content_json, istnieje error_message
```

### 7.5. Koszty i użycie

```text
prompt_tokens
completion_tokens
total_tokens
access_count
last_accessed_at
started_at
completed_at
created_at
updated_at
```

Cache HIT zwiększa `access_count` i aktualizuje `last_accessed_at`.

Otwarcie materiału z Historii jest operacją tylko do odczytu i nie zmienia tych pól.

Znaczenie dat:

```text
created_at
→ data utworzenia materiału
→ wyświetlana w Historii jako „Wygenerowano”

last_accessed_at
→ data ostatniego użycia cache przez Generator
→ używana do sortowania Historii
```

### 7.6. RLS

Nauczyciel może odczytać wyłącznie własne rekordy:

```text
owner_id = auth.uid()
```

Zapis i aktualizacja odbywają się przez serwerowy Route Handler.

Weryfikacja live Supabase z 02.08.2026 potwierdziła:

```text
RLS enabled = true
RLS forced = false

policy:
generated_materials_select_own
→ rola authenticated
→ SELECT
→ owner_id = auth.uid()

granty tabeli:
authenticated
→ SELECT

anon
→ brak grantu
```

Frontend Historii wykonuje wyłącznie odczyt. Nie otrzymuje praw `INSERT`, `UPDATE` ani `DELETE`.

---

## 8. GENERATION FINGERPRINT

Fingerprint generowania obejmuje wszystkie dane wpływające na wynik:

```text
sourceFingerprint
lessonTopicId
topicTitle
materialType
taskCount
profiles
taskPlan
generatorVersion
contentSchemaVersion
model
```

Następnie:

```text
kanoniczny JSON
→ SHA-256
→ generation_fingerprint
```

Profile są kanonizowane, dlatego inna kolejność zaznaczenia tych samych profili nie tworzy nowego fingerprintu.

Zmiana któregokolwiek elementu manifestu powoduje cache MISS.

---

## 9. ATOMOWY CLAIM CACHE

Wdrożona funkcja:

```text
public.claim_generated_material(...)
```

Migracja:

```text
supabase/sql/2026-07-29_claim_generated_material.sql
```

Funkcja działa jako `security definer` i jest wykonywana przez `service_role`.

Decyzja wykonywana jest atomowo w PostgreSQL:

```text
brak rekordu
→ INSERT generating
→ reserved

ready
→ access_count + 1
→ last_accessed_at = teraz
→ hit + content_json

świeży generating
→ in_progress

failed albo generating starszy niż 10 minut
→ reset do generating
→ reserved
```

Mechanizm:

```text
INSERT ... ON CONFLICT DO NOTHING
→ SELECT ... FOR UPDATE
→ decyzja stanu
```

To eliminuje retry loops i ręczne odtwarzanie transakcji w JavaScript.

Kolumny wyniku RPC mają prefiks `claim_` tam, gdzie nazwa mogłaby kolidować z kolumną tabeli:

```text
claim_content_json
claim_access_count
claim_started_at
```

Zapobiega to niejednoznaczności PL/pgSQL, np. dla `access_count`.

---

## 10. WARSTWA JAVASCRIPT CACHE

Plik:

```text
lib/generation/generatedMaterialsCache.js
```

Eksportuje:

```text
claimGeneratedMaterial()
markGeneratedMaterialReady()
markGeneratedMaterialFailed()
```

Odpowiedzialność:

- walidacja kontraktu RPC,
- mapowanie nazw pól SQL na kontrakt JavaScript,
- warunkowy zapis `ready`,
- warunkowy zapis `failed`.

Logika współbieżności pozostaje w PostgreSQL.

Aktualizacje `ready` i `failed` są chronione przez:

```text
id
+ owner_id
+ status = generating
+ started_at rezerwacji
```

---

## 11. CACHE HIT I MISS

### Cache HIT

```text
status = ready
→ RPC zwiększa access_count
→ odczyt content_json
→ 0 wywołań modelu
→ usage bieżącego requestu = 0 / 0 / 0
→ renderery
```

### Cache MISS

```text
status = generating
→ jedno wywołanie modelu
→ Structured Outputs
→ parser
→ content_json + usage
→ status = ready
```

Potwierdzone testy:

```text
MISS 6 zadań, Standard + ADHD:
4650 prompt + 1572 completion = 6222 total

HIT identycznego requestu:
0 prompt + 0 completion = 0 total
access_count: 1 → 2

MISS 7 zadań, Standard:
3901 prompt + 1391 completion = 5292 total
```

---

## 12. HISTORIA GENEROWAŃ — WDROŻONA

Nie utworzono osobnej tabeli `generation_requests`.

Historia korzysta bezpośrednio z rekordów:

```text
generated_materials
→ status = ready
→ owner_id = auth.uid()
→ aktywny subject_id
```

### 12.1. Warstwa kodu

Wdrożone pliki:

```text
lib/generation/generatedMaterialsHistoryApi.js
app/przedmioty/[subjectKey]/historia/page.jsx
```

Istniejący komponent podglądu:

```text
components/generator/GeneratedMaterial.jsx
```

jest ponownie używany do otwierania zapisanego materiału.

### 12.2. Lista metadanych

Pierwsze zapytanie nie pobiera `content_json`.

Lista pobiera:

```text
id
subject_id
subject_name_snapshot
topic_title_snapshot
material_type
task_count
profiles
access_count
last_accessed_at
content_schema_version
created_at
```

Warunki:

```text
owner_id = aktualny użytkownik
subject_id = aktywny przedmiot
status = ready
```

Sortowanie:

```text
last_accessed_at DESC
id DESC
```

Paginacja:

```text
50 rekordów
→ „Pokaż więcej”
```

Filtr:

```text
Wszystkie typy
karta pracy
kartkówka
sprawdzian
```

### 12.3. Otwarcie materiału

Po kliknięciu „Otwórz” wykonywane jest drugie zapytanie dla jednego rekordu.

Dodatkowe pola:

```text
task_plan
content_json
```

Zapytanie ponownie filtruje po:

```text
id
owner_id
subject_id
status = ready
```

Przed renderowaniem kontrolowane są:

```text
obsługiwany material_type
obsługiwana wersja content_schema_version dla danego typu
niepusta lista profiles
content_json jako obiekt
tasks jako niepusta tablica
tasks.length = task_count
```

Historia obsługuje:

```text
karta pracy → material_schema_v2, material_schema_v3
kartkówka    → material_schema_v1, material_schema_v2
sprawdzian  → material_schema_v1, material_schema_v2
```

Starsze pole `context` w `open_explain` nie jest renderowane uczniowi.

### 12.4. Zachowanie tylko do odczytu

Otwarcie z Historii:

- nie wywołuje `/api/generate`,
- nie wywołuje modelu,
- nie wywołuje `claim_generated_material`,
- nie tworzy nowego rekordu,
- nie aktualizuje `access_count`,
- nie aktualizuje `last_accessed_at`,
- nie odczytuje ponownie DOCX ani chunków,
- nie uruchamia parsera odpowiedzi modelu.

Materiał jest renderowany z istniejącego `content_json`.

### 12.5. UI, eksport PDF i eksport DOCX

Materiał otwiera się na tej samej stronie Historii.

Dostępne są:

```text
„Wróć do historii”
„Drukuj / Zapisz PDF”
„Pobierz DOCX”
```

Historia pokazuje:

```text
created_at
→ „Wygenerowano”
```

PDF jest generowany ponownie przez przeglądarkę z zapisanego `content_json`.

DOCX jest budowany klientowo po kliknięciu przez dynamicznie załadowany `lib/export/exportDocx.js`. Eksporter otrzymuje istniejący `content_json`, profile i aktualną skalę ocen. Nie wywołuje Generatora ani modelu.

PDF i DOCX nie są przechowywane jako pliki w Storage. Treść materiału pozostaje ta sama, ale przyszłe zmiany CSS mogą zmienić wygląd PDF, a zmiany eksportera mogą zmienić wygląd ponownie pobranego DOCX.

### 12.6. Live schemat i dane

Weryfikacja live Supabase z 02.08.2026 potwierdziła wcześniejsze rekordy kartkówki `material_schema_v1`.

Test runtime z 03.08.2026 potwierdził zapis karty pracy:

```text
material_type = karta pracy
status = ready
content_schema_version = material_schema_v3
access_count = 1
content_json istnieje
prompt_tokens = 3855
completion_tokens = 1447
total_tokens = 5302
```

Historia wyświetliła i ponownie wyrenderowała ten rekord bez wywołania modelu.

Indeks Historii:

```text
generated_materials_owner_subject_history_idx
→ owner_id
→ subject_id
→ last_accessed_at DESC
→ WHERE status = ready
```

Filtr `karta pracy` pokazuje zapisane rekordy. Filtr `sprawdzian` pozostaje pusty do uruchomienia tego przepływu.

Osobną tabelę zdarzeń można dodać później wyłącznie po pojawieniu się realnej potrzeby audytu każdego kliknięcia, retry albo rozliczeń per request.

---

## 12.7. Kontrakt treści materiałów

Aktualny parser zapisuje wyłącznie wynik po walidacji Structured Outputs.

Karta pracy:

```text
intro: string
tip: array
glossary: array
tasks: array
```

Kartkówka:

```text
intro = ""
tip = []
glossary = []
tasks: array
```

`open_explain`:

```text
instruction
expectedAnswer
answerExplanation
```

Pole `context` nie należy do aktualnego kontraktu ucznia. Historyczne pole może istnieć w starszym `content_json`, ale renderer i normalizacja go ignorują.

Warstwy ASD, ADHD, Dysleksji i Obcojęzycznego są prezentacją tego samego bazowego zestawu zadań, nie osobnymi rekordami ani osobnymi wywołaniami modelu.

---

## 13. WSPÓLNY KLUCZ, PUNKTACJA I SKALA OCEN — WDROŻONE

### 13.1. Wspólny klucz nauczyciela

Wspólny klucz nie jest osobnym rekordem bazy i nie wymaga nowej tabeli.

Przepływ:

```text
generated_materials.content_json
→ components/generator/GeneratedMaterial.jsx
→ lib/generation/buildTeacherAnswerKey.js
→ components/generator/TeacherAnswerKey.jsx
```

Klucz:

- jest budowany z istniejących pól odpowiedzi i wyjaśnień siedmiu typów zadań,
- występuje jeden raz po wszystkich profilach uczniowskich,
- działa w Generatorze i Historii przez ten sam komponent,
- nie uruchamia modelu,
- nie zmienia `content_json`,
- nie tworzy nowego rekordu `generated_materials`,
- jest zawsze widoczny na wydruku i rozpoczyna się na nowej stronie.

### 13.2. Punktacja

Źródło prawdy:

```text
lib/generation/scoring.js
```

Aktualna mapa:

```text
closed_single  → 1 pkt
closed_tf      → 1 pkt
match_fill     → 2 pkt
error_find     → 2 pkt
match_pair     → 3 pkt
open_code      → 3 pkt
open_explain   → 3 pkt
```

Punkty są wyliczane w warstwie aplikacji na podstawie `taskSubtype`. Nie są generowane przez model i nie są zapisywane jako osobne pola w `generated_materials`.

Dla aktualnych `templates.js` suma zależy od typu materiału i liczby zadań:

```text
karta pracy  → 5 zadań: 11 pkt | 6 zadań: 14 pkt | 7 zadań: 17 pkt
kartkówka    → 5 zadań:  9 pkt | 6 zadań: 14 pkt | 7 zadań: 19 pkt
sprawdzian   → 5 zadań:  9 pkt | 6 zadań: 14 pkt | 7 zadań: 19 pkt
```

Test buduje każdy plan przez `buildTaskPlan()` i pobiera typy z `templates.js`. Nie istnieje jedna uniwersalna suma dla samej liczby 5 / 6 / 7. Kartkówka i sprawdzian mają obecnie takie same sumy, ponieważ ich aktualne szablony zawierają tę samą liczbę zadań o poszczególnych wagach; po zmianie szablonów sumy mogą się różnić.

Stara statyczna `GRADE_SCALE` oraz `renderGradeScale()` zostały usunięte z `scoring.js`. Nie istnieje drugi kodowy słownik progów ocen.

Korekta testu sum punktów nie zmienia schematu Supabase, `content_json`, `generated_materials`, `generation_fingerprint` ani cache. Jest wyłącznie regresją kodową opartą na aktualnym planie z `templates.js`.

### 13.3. `teacher_grade_scales`

Tabela przechowuje jeden aktywny zestaw progów dla nauczyciela.

Migracja:

```text
supabase/sql/2026-08-03_teacher_grade_scales.sql
```

Pola:

```text
owner_id uuid primary key
  → auth.users(id) on delete cascade

grade_2_min smallint not null
grade_3_min smallint not null
grade_4_min smallint not null
grade_5_min smallint not null
grade_6_min smallint not null

scale_schema_version text not null
  → teacher_grade_scale_v1

created_at timestamptz not null
updated_at timestamptz not null
```

Constraints:

```text
każdy próg: 1–100

grade_2_min
< grade_3_min
< grade_4_min
< grade_5_min
< grade_6_min

scale_schema_version = teacher_grade_scale_v1
```

Trigger aktualizuje `updated_at` przed każdym `UPDATE`.

Ocena 1 nie ma osobnej kolumny. Jej zakres zawsze rozpoczyna się od `0%`. Górne granice wszystkich ocen są wyliczane w aplikacji na podstawie kolejnego progu minimalnego.

### 13.4. RLS i granty skali

Tabela ma włączone RLS.

`authenticated`:

```text
SELECT własnego rekordu
INSERT własnego rekordu
UPDATE własnego rekordu
```

Warunek każdej polityki:

```text
owner_id = auth.uid()
```

`authenticated` nie otrzymuje `DELETE`. `anon` nie ma żadnego grantu. `service_role` ma pełne prawa techniczne.

### 13.5. Warstwa aplikacji

Logika i API:

```text
lib/gradeScale/teacherGradeScale.js
lib/gradeScale/teacherGradeScaleApi.js
```

UI:

```text
app/ustawienia/page.jsx
```

Formularz:

- zawiera pięć progów dla ocen 2–6,
- nie obsługuje importu CSV,
- waliduje liczby całkowite, zakres `1–100` i ścisłą kolejność,
- wykonuje `upsert` po `owner_id`,
- pokazuje podgląd sześciu wyliczonych zakresów.

Domyślne wartości widoczne przed pierwszym zapisem:

```text
40 / 55 / 70 / 85 / 95
```

Wartości stają się aktywną skalą dopiero po zapisie rekordu.

### 13.6. Relacja z `teacher_profiles`

Weryfikacja live Supabase z 03.08.2026 potwierdziła istniejącą tabelę `teacher_profiles` z polami:

```text
id
user_id
display_name
email
role
is_active
created_at
updated_at
```

Skala nie została dopisana do `teacher_profiles`. `teacher_grade_scales` jest odrębnym bytem biznesowym i jest powiązana bezpośrednio z `auth.users` przez `owner_id`.

### 13.7. Semantyka Historii i cache

Zatwierdzona reguła:

```text
jedna aktywna skala konta
→ aktualna skala jest używana także przy wcześniejszych materiałach z Historii
```

Skala jest pobierana klientowo przez `GeneratedMaterial` podczas renderowania. Ten sam przepływ działa bezpośrednio po generowaniu oraz po otwarciu zapisanego `content_json` z Historii.

Skala nie jest snapshotem materiału i nie należy do:

- `content_json`,
- `content_schema_version`,
- `generation_fingerprint`,
- `claim_generated_material`,
- tożsamości cache,
- usage tokenów.

Zmiana progów:

- nie uruchamia `/api/generate`,
- nie tworzy nowego rekordu `generated_materials`,
- nie zwiększa `access_count`,
- nie aktualizuje `last_accessed_at`,
- jest widoczna przy ponownym otwarciu także starszego materiału.

Przy braku zapisanego rekordu materiał pozostaje dostępny. UI pokazuje odnośnik do `/ustawienia`, a sekcja skali nie jest drukowana.

### 13.8. Regresja

Potwierdzono:

- zapis i aktualizację jednego rekordu skali,
- odczyt skali po odświeżeniu,
- działanie skali w Generatorze,
- działanie skali dla wcześniejszego materiału z Historii,
- poprawny układ dwóch kolumn w wydruku / PDF,
- poprawne zakresy dla `40 / 55 / 70 / 85 / 95`,
- poprawne testy `testTeacherGradeScale.mjs` i `testTeacherAnswerKey.mjs`,
- czysty lint i build.

## 14. EKSPORT DOCX — WDROŻONY

### 14.1. Warstwa kodu

```text
components/generator/GeneratedMaterial.jsx
→ przycisk „Pobierz DOCX”
→ dynamiczny import eksportera

lib/export/exportDocx.js
→ buildMaterialDocx()
→ exportMaterialToDocx()

scripts/testExportDocx.mjs
→ test rzeczywistej serializacji i treści DOCX
```

Zależność klienta:

```text
docx = 9.5.1
```

`file-saver` nie jest używany. Blob jest pobierany przez natywny, tymczasowy link przeglądarki.

### 14.2. Kontrakt wejścia

Eksporter otrzymuje:

```text
materialTypeValue
materialTypeLabel
topicTitle
profiles [{ value, label }]
material = sparsowany content_json
gradeScale = aktualna skala konta albo null
```

Nie odczytuje ponownie:

- `teacher_documents`,
- `document_blocks`,
- `document_chunks`,
- modelu,
- cache claimu.

### 14.3. Źródła prawdy

```text
getTaskProfilePresentation()
→ prezentacja ASD i ADHD

getTaskPoints()
→ punktacja zadań ucznia

buildTeacherAnswerKey()
→ jeden wspólny klucz

buildTeacherGradeScaleRanges()
→ aktualna skala ocen
```

Eksporter nie utrzymuje równoległej mapy punktów, skali ani reguł profili.

### 14.4. Budowa dokumentu

```text
aktualny content_json
→ sekcja ucznia dla każdego profilu
→ każdy kolejny profil od nowej strony
→ jeden wspólny klucz na końcu
→ A4
→ Packer.toBlob()
→ pobranie pliku
```

Karta pracy zawiera `intro`, `tip` i słowniczek tylko dla profilu Obcojęzycznego. Bloki kodu używają czcionki monospace i zachowują podziały wierszy oraz wcięcia.

### 14.5. Relacja z bazą i Historią

Eksport DOCX:

- nie tworzy tabeli ani migracji,
- nie zapisuje rekordu `material_exports`,
- nie tworzy nowego `generated_materials`,
- nie aktualizuje `access_count` ani `last_accessed_at`,
- nie zmienia `content_json`,
- nie wpływa na `generation_fingerprint`,
- nie zapisuje pliku w Storage,
- działa także po otwarciu istniejącego materiału z Historii.

### 14.6. Regresja

Automatyczny test obejmuje kartę pracy 7 zadań × 5 profili, jeden słowniczek, jeden klucz, sumę 17 pkt, skalę ocen, wielowierszowy kod oraz kartkówkę z `closed_tf` i sumą 9 pkt.

Runtime w Microsoft Word potwierdził eksport kart pracy i kartkówek z Historii, nową stronę dla profili, jeden klucz, prawidłowe sumy 9 / 11 / 14 pkt oraz zachowanie operatorów i wcięć kodu. Testy Node, lint i build są czyste; pakiet został zatwierdzony w repozytorium.

---

## 15. ELEMENTY WYCOFANE I ZACHOWANE

### Coverage

Wycofany mechanizm coverage został usunięty z aktywnego projektu:

- sześć modułów coverage usunięto z `lib/privateRag`,
- testy wycofanej architektury usunięto lub zastąpiono aktualnymi,
- tabela `private_rag_task_type_coverage_cache` została usunięta,
- Route Handler nie używa `coverage`, `isSupported` ani `buildSafeTaskPlan`.

Coverage pozostaje wyłącznie w historycznych checkpointach `smartteacher_etapy.md`.

### Semantic retrieval

Funkcje semantic search, chunki i embeddingi pozostają w bazie.

Nie są używane przez aktualny Route Handler dla jednego krótkiego DOCX, ale nie należy ich usuwać bez osobnej decyzji dotyczącej długich albo wielu dokumentów.

## 16. CLEANUP BAZY — ZAKOŃCZONY

Cleanup po stabilizacji Generatora wykonano w trzech oddzielnych migracjach.

### 16.1. Usunięcie coverage cache

Migracja:

```text
supabase/sql/2026-07-30_drop_private_rag_task_type_coverage_cache.sql
```

Usunięto:

```text
public.private_rag_task_type_coverage_cache
```

Operacja została wykonana bez `CASCADE`. Kontrola końcowa potwierdziła `coverage_table_exists = false`.

### 16.2. Usunięcie zduplikowanych indeksów katalogu

Migracja:

```text
supabase/sql/2026-07-31_drop_duplicate_catalog_indexes.sql
```

Zachowano indeksy kanoniczne:

```text
lesson_sections_catalog_order_idx
lesson_topics_catalog_section_order_idx
```

Usunięto strukturalnie identyczne duplikaty:

```text
lesson_sections_catalog_active_order_idx
lesson_topics_catalog_section_active_order_idx
```

Migracja przed usunięciem sprawdzała równoważność strukturalną i brak powiązania z constraintem.

### 16.3. Cleanup przeciążenia RPC importu CSV

Migracja:

```text
supabase/sql/2026-07-31_cleanup_lesson_catalog_rpc_overload.sql
```

Usunięto stare przeciążenie:

```text
create_private_lesson_catalog_from_import(uuid, uuid, text, text, text)
```

Pozostawiono:

```text
create_private_lesson_catalog_from_import(uuid, uuid, uuid, text, text, text)
```

Dla aktualnej funkcji potwierdzono:

```text
SECURITY DEFINER = true
PUBLIC EXECUTE   = false
anon EXECUTE     = false
authenticated    = true
```

Ponowny import CSV po migracji potwierdził utworzenie katalogu przypisanego do wybranej klasy.

### 16.4. Elementy świadomie pozostawione

Nie usunięto:

- `document_blocks`,
- `document_chunks`,
- `document_embeddings`,
- funkcji semantic search,
- `generated_materials`,
- `claim_generated_material`,
- danych katalogu CSV,
- polityk RLS wyglądających na nakładające się.

Polityki RLS wymagają osobnego audytu pełnej macierzy ról i nie były częścią cleanupu przed startem sprzedaży.

## 17. STORAGE

### `teacher-documents`

Prywatny bucket na źródłowe CSV i DOCX. Ścieżki muszą uwzględniać właściciela.

### Eksporty

PDF i DOCX wygenerowanych materiałów nie są przechowywane w osobnej tabeli ani bucketcie.

PDF jest tworzony przez aktualny renderer i mechanizm wydruku przeglądarki. DOCX jest budowany klientowo przez `lib/export/exportDocx.js` z `content_json` i aktualnej skali ocen. Trwały cache eksportów zostanie zaprojektowany dopiero, gdy pojawi się realna potrzeba biznesowa.

---

## 18. ŚWIADOMIE ODŁOŻONE ELEMENTY

Nie wdrażać w najbliższym pakiecie:

- `generation_requests`,
- `generation_request_sources`,
- `generated_material_outputs`,
- `generation_usage_logs`,
- `material_exports`,
- `knowledge_units`,
- wiele dokumentów dla jednego tematu,
- hybrid search,
- reranking,
- HNSW,
- grupy A/B,
- shuffle.

Każdy element wymaga osobnej potrzeby biznesowej i testu.

---

## 19. KOLEJNOŚĆ DALSZEGO WDROŻENIA

Zakończone:

```text
1. pełny odczyt dokumentu
2. taskPlan z templates.js dla 5 / 6 / 7
3. generation_fingerprint
4. atomowy cache generated_materials
5. refactor Route Handlera
6. testy MISS / HIT / no_sources
7. cleanup coverage
8. usunięcie zduplikowanych indeksów
9. cleanup starego przeciążenia RPC importu CSV
10. regresja lokalna i na Vercel
11. podłączenie Historii do generated_materials
12. odczyt jednego content_json bez wywołania modelu
13. ponowny wydruk / PDF z Historii
14. jeden wspólny klucz nauczyciela
15. punktacja siedmiu typów zadań
16. indywidualna skala ocen nauczyciela
17. aktualna skala także dla wcześniejszych materiałów z Historii
```

Zakończone dodatkowo:

```text
18. cleanup nieużywanych modułów starego projektu
19. karta pracy dla wszystkich profili
20. intro, tip i słowniczek w jednym wywołaniu modelu
21. material_schema_v3 dla karty pracy
22. open_explain bez context dla ucznia
23. ponowny wydruk karty pracy z Historii
24. końcowa regresja karty pracy 6 / 7 + HIT / no_sources
25. regresja punktacji: 3 typy materiałów × 5 / 6 / 7
26. audyt i eksport DOCX
```

Następnie:

```text
27. regresja kartkówki material_schema_v2
28. sprawdzian
29. limity, koszty i sprzedaż
```

## 20. DECYZJE OBOWIĄZUJĄCE

1. `lesson_topic_id` jest głównym kluczem operacyjnym tematu.
2. Jeden krótki DOCX opisuje jeden temat.
3. Pełny dokument jest kontekstem Generatora dla tego przypadku.
4. Liczba zadań wynosi 5, 6 albo 7.
5. Typy zadań wynikają z `templates.js`.
6. Struktura wynika z JSON Schema i parsera.
7. Model nie wybiera ani nie ocenia typów.
8. Coverage nie należy do runtime i zostało usunięte z kodu oraz bazy.
9. Cache przechowuje gotowy wynik po parserze.
10. `generated_materials` zasila cache i Historię.
11. Claim cache jest atomowy i wykonywany w PostgreSQL.
12. JavaScript pozostaje cienkim adapterem do RPC i aktualizacji statusów.
13. Cache HIT nie uruchamia modelu i zwraca usage `0 / 0 / 0` dla bieżącego requestu.
14. Semantic retrieval pozostaje opcją dla większej skali źródeł.
15. W katalogu pozostają wyłącznie kanoniczne indeksy kolejności sekcji i tematów.
16. Import CSV używa wyłącznie funkcji z `p_grade_level_id`.
17. Aktualne RPC importu CSV jest dostępne dla `authenticated`, nie dla `PUBLIC` ani `anon`.
18. Rzeczywiste nazwy kolumn, funkcji i uprawnień należy weryfikować na aktualnym schemacie Supabase.
19. Migracji destrukcyjnych nie wykonujemy z `CASCADE`, jeśli nie ma osobnej, jawnie uzasadnionej decyzji.
20. Historia jest wdrożona i opiera się bezpośrednio na `generated_materials`.
21. Lista Historii pobiera metadane bez `content_json`; treść jest pobierana dopiero po kliknięciu „Otwórz”.
22. Otwarcie Historii jest tylko do odczytu i nie zmienia `access_count` ani `last_accessed_at`.
23. Historia pokazuje `created_at` jako datę „Wygenerowano”, a sortuje według `last_accessed_at DESC`.
24. Historia ponownie używa `GeneratedMaterial` i istniejącego wydruku / PDF.
25. Jeden wspólny klucz nauczyciela jest budowany z istniejącego `content_json` bez dodatkowego wywołania modelu.
26. Punkty wynikają z `taskSubtype` i `lib/generation/scoring.js`, a nie z decyzji modelu.
27. Skala ocen jest osobnym ustawieniem w `teacher_grade_scales`, nie polem `teacher_profiles`.
28. Jedna osoba ma jeden aktywny rekord skali identyfikowany przez `owner_id`.
29. Skala nie jest zapisywana w `generated_materials` i nie wpływa na `generation_fingerprint` ani cache.
30. Aktualna skala konta jest używana również przy wcześniejszych materiałach z Historii.
31. Import skali ocen z CSV nie jest częścią aktualnego produktu.
32. Karta pracy dla wszystkich profili jest aktywna i korzysta z `material_schema_v3`.
33. `intro`, `tip`, `glossary` i `tasks` karty pracy powstają w jednym wywołaniu modelu.
34. `open_explain` nie zawiera `context` pokazywanego uczniowi.
35. Historia obsługuje wersje kontraktów per `material_type`, nie jeden globalny string.
36. Zmiana CSS lub renderera zmienia ponownie wygenerowany PDF z Historii bez zmiany `content_json` i bez wywołania modelu.
37. Końcowa regresja karty pracy i macierz punktacji 3 × 3 są zakończone.
38. Eksport DOCX jest budowany na żądanie z istniejącego `content_json`, profili i aktualnej skali ocen.
39. Eksport DOCX działa w Generatorze i Historii przez `GeneratedMaterial`; nie wywołuje modelu ani Route Handlera Generatora.
40. DOCX nie jest przechowywany w Storage ani w osobnej tabeli i nie zmienia `access_count`, `last_accessed_at`, `content_json` ani `generation_fingerprint`.
41. Eksporter używa istniejących źródeł prawdy: `getTaskProfilePresentation`, `getTaskPoints`, `buildTeacherAnswerKey` i `buildTeacherGradeScaleRanges`.
42. Pakiet eksportu DOCX jest zakończony. Następnym krokiem jest regresja kartkówki `material_schema_v2`, ze szczególną kontrolą samowystarczalności `open_explain`.
